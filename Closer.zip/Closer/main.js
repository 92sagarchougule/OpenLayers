window.onload = init

function init(){

    //const scaleLine = new ol.control.ScaleLine();
    //const mpost = new ol.control.MousePosition({
        //coordinates: coordinate.format(5)
    //});
    var attri = new ol.control.Attribution();

    // Controls

    const map = new ol.Map({
        view: new ol.View({
            center:[8750950.149357125,2720206.7600791054],
            zoom:4.2
        }),
        layers:[
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        target:'map',
        //controls : ol.control.defaults({ zoom: false, attribution: false }).extend([scaleLine,mpost, attri])
    });
    const popupNewContainer = document.getElementById('popup-container');

    const  popupContainer = document.getElementById('popup-coordinate');
    var closer = document.getElementById('popup-closer');

    const popup = new ol.Overlay({
        element:popupNewContainer
    })

    closer.onclick = function() {
        popup.setPosition(undefined);
        closer.blur();
        return false;
    };

    map.addOverlay(popup);

    map.on('click', function(e){
        var clicked = e.coordinate;
        popup.setPosition(undefined);
        popup.setPosition(clicked);
        popupContainer.innerHTML = clicked;
    })
    
/*
    const dragBox = new ol.interaction.DragBox({
        className:'dragBox'
    })

    dragBox.on('boxstart', function(evt){
        //console.log('drag start');
    })

    dragBox.on('boxend', function(evt){
        //console.log('drag end')

        map.getView().fit(dragBox.getGeometry().getExtent(), map.getSize())
    })

    map.addInteraction(dragBox);
    */

    var dragSource = new ol.source.Vector()

    var dragLayer = new ol.layer.Vector({
        source:dragSource
    })

    map.addLayer(dragLayer);

    var dragDrop = new ol.interaction.DragAndDrop({
        formatConstructors:[ol.format.GeoJSON],
        source:dragSource
    })

    map.addInteraction(dragDrop);

}