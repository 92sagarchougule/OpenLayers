window.onload = init

function init(){

    // Controls

    const map = new ol.Map({
        view: new ol.View({
            center:[8416686.663317095, 1731974.509331715],
            zoom:5
        }),
        layers:[
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        target:'map'
    });
    const popupNewContainer = document.getElementById('popup-container');

    const  popupContainer = document.getElementById('popup-coordinate');
    var closer = document.getElementById('popup-closer');

    const popup = new ol.Overlay({
        element:popupNewContainer
    })

    closer.onclick = function() {
        popup.setPosition(undefined);
        closer.blur();
        return false;
    };

    map.addOverlay(popup);

    map.on('click', function(e){
        var clicked = e.coordinate;
        popup.setPosition(undefined);
        popup.setPosition(clicked);
        popupContainer.innerHTML = clicked;
    })
    
}