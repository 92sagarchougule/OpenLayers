$(document).ready(function(){

    $('#name').click(function(){
        $(this).hide();
        $(this).addClass('temp');
    })



    $('#s').click(function(){
        $('#name').show();
    })

    

})