// List of used variables
var params_geoserver, cropsap1, params, Filter_tal, geojson, divison_geojson, district_geojson, taluka_geojson, cropsap, geojson_dist_cropsap, dist_text, district_text, distname, geojson_tal_cropsap, basemap, geojson_District, cropsap_dist,
	div_value, districtLayer, base, legend_crop, imagem, table, circle_geojson, circle_Layer, loadingIndicator, talukaLayer, circleLayer, villageLayer, village_geojson;

loadingIndicator = document.getElementById('loading-indicator');

document.getElementById("menu").onclick = function () { // var hide_Select = document.getElementById('menu');
	let form_tags = document.getElementById('form');
	if (form_tags.style.display === "none") {
		form_tags.style.display = "block";
	} else {
		form_tags.style.display = "none";
	}


};


let hide_Select = document.getElementById('menu')


// loading indicator--------------------------------------------
document.onreadystatechange = function () {
	if (document.readyState !== "complete") {
		document.querySelector("body").style.visibility = "hidden";
		document.getElementById("loading_indicator").style.visibility = "visible";
	} else {
		setTimeout(() => {
			document.getElementById("loading_indicator").style.display = "none";
			document.querySelector("body").style.visibility = "visible";
		}, 3000)
	}
};












// ----------------------------------------------------------------------------------------------------------------------

































//-------- Basic Layer and Map Class-------------------------------------------------------------------------------

districtLayer = new ol.layer.Tile({
	title: "District",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:District_Boundary",
			TILED: true,
		},
	}),
});

var ContourLayer = new ol.layer.Tile({
	title: "Contour",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Contour",
			TILED: true,
		},
	}),
});

var Rail_Track_Layer = new ol.layer.Tile({
	title: "Rail Track",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Rail_Track",
			TILED: true,
		},
	}),
});


var Road_Layer = new ol.layer.Tile({
	title: "Road",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Road",
			TILED: true,
		},
	}),
});



var Settlement_Point = new ol.layer.Tile({
	title: "Settlement Location",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Settlement_Point",
			TILED: true,
		},
	}),
});




var Taluka_Boundary = new ol.layer.Tile({
	title: "Taluka",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Taluka_Boundary",
			TILED: true,
		},
	}),
});




var Village_Boundary = new ol.layer.Tile({
	title: "Village",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Village_Boundary",
			TILED: true,
		},
	}),
});


// Define the label style
var labelStyle = new ol.style.Style({
    text: new ol.style.Text({
        font: '13px Calibri,sans-serif',
        overflow: true,
        fill: new ol.style.Fill({
            color: 'sky blue'
        }),
        stroke: new ol.style.Stroke({
            color: 'sky blue',
            width: 0.1
        }),
        textAlign: 'center',
        textBaseline: 'middle',
        offsetY: 0 // Adjust this value to move the label position
    })
});

// Create the WFS URL
var urls = "http://localhost:8282/geoserver/portal/ows" + '?service=WFS&version=1.0.0&request=GetFeature&typeName=' + 'Village_Boundary' + '&outputFormat=application/json';

// Create the vector layer with the WFS source
var village_name = new ol.layer.Vector({
    source: new ol.source.Vector({
        format: new ol.format.GeoJSON(),
        url: urls
    }),
    style: function(feature, resolution) {
        // Get current map resolution (meters per pixel)
        var currentResolution = resolution;  // This gives the map resolution in meters per pixel

        // Define resolution thresholds for visibility based on scale 1:110104
        var scaleVisibility = false;

        // For example: scale 1:110104 could correspond to a resolution between 0.0001 and 0.0002 meters/pixel.
        // These values need to be adjusted based on your map's projection and actual scale.

        var minResolution = 0.0001;  // Example: minimum resolution for 1:110104 scale
        var maxResolution = 0.0002;  // Example: maximum resolution tolerance for scale 1:110104

        // Check if the current resolution is within the desired range
        if (currentResolution >= minResolution && currentResolution <= maxResolution) {
            scaleVisibility = true;
        }

        // If scaleVisibility is true, show label, otherwise, hide it
        if (scaleVisibility) {
            labelStyle.getText().setText(feature.get('name')); // Use 'name' attribute for the label
        } else {
            labelStyle.getText().setText(''); // Hide label if not in the resolution range
        }

        return labelStyle;
    }
});









// // Create a new vector layer with the WFS source
// var village_name = new ol.layer.Vector({
//     source: new ol.source.Vector({
//         format: new ol.format.GeoJSON(),
//         url: urls
//     }),
//     style: function(feature, resolution) {
//         // Adjust the visibility based on the resolution (zoom level)
//         var zoomLevel = map.getView().getZoom(); // Get the current zoom level
//         var scaleVisibility = true; // Default is to show the label

//         // Define zoom range conditions for visibility (you can adjust these values)
//         if (zoomLevel < 3) {
//             scaleVisibility = false; // Hide label on zoom level 10 or below
//         } else if (zoomLevel >= 3 && zoomLevel < 5) {
//             scaleVisibility = true;  // Show label for zoom levels 10-11
//         } else if (zoomLevel >= 5) {
//             scaleVisibility = true;  // Show label for zoom levels 12 and above
//         }

//         // If scaleVisibility is true, show label, otherwise, hide it
//         if (scaleVisibility) {
//             labelStyle.getText().setText(feature.get('name')); // Use the 'name' attribute as the label
//         } else {
//             labelStyle.getText().setText(''); // Hide the label if not in the zoom range
//         }

//         return labelStyle;
//     }
// });





var Watershed_Prority_Boundary = new ol.layer.Tile({
	title: "Watershed Prority",
	source: new ol.source.TileWMS({
		url: "http://localhost:8282/geoserver/portal/wms?", 
		crossOrigin: "Anonymous",
		serverType: "geoserver",
		visible: true,
		params: {
			LAYERS: "portal:Watershed_Prority_Boundary",
			TILED: true,
		},
	}),
});





basemap = new ol.layer.Tile({
	type: 'base',
	visible: true,
	source: new ol.source.XYZ({
		// attributions: 'Tiles � <a href="https://services.arcgisonline.com/ArcGIS/' +
		//     'rest/services/World_Topo_Map/MapServer">ArcGIS</a>',
		url: 'https://server.arcgisonline.com/ArcGIS/rest/services/' +
			'World_Topo_Map/MapServer/tile/{z}/{y}/{x}',
		crossOrigin: 'Anonymous',
	})
});


// -----------------------------------------------------------------------------------------------------------------------------------------------------------
// ------------------------------------------- API from Select Agri Division----------------------------------------------


let map = new ol.Map({
	target: 'map',
	layers: [],
	//overlays: [overlay],

	interactions: ol.interaction.defaults({
		mouseWheelZoom: true,
		doubleClickZoom: false,
		dragAndDrop: false,
		keyboardPan: false,
		keyboardZoom: false,
		DragZoom: false,
		DragPan: false,
		pointer: false,
		select: false,
		DragRotate: false,
		PinchRotate: false,
		PinchZoom: false,
	}),
	controls: ol.control.defaults({
		attribution: false
	}),

	view: new ol.View({
		center: [8245824.58455327, 2110000.0303739905],
		zoom: 8.9,
		constrainOnlyCenter: true,
		smoothExtentConstraint: false
	}),
});




//----------------------------------------------------------------------------------------------------------------


// Taluka List-------------------------------------------

var settings = {
	"url": "http://localhost:8282/geoserver/portal/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=portal%3ATaluka&maxFeatures=50&outputFormat=application%2Fjson",
	"method": "GET",
	"timeout": 0,
  };
  
  $.ajax(settings).done(function (response) {
	// console.log(response.features);
	var talukaName = [];
	var talukaCode = [];
	var tal = response.features;
	tal.forEach((item) => {
		// console.log(item.properties.thname11);  // Log the name
		// console.log(item.properties.thncode11);  // Log the code
	
		// Push values into the arrays
		talukaCode.push(item.properties.thncode11);
		talukaName.push(item.properties.thname11);
	});
	
	// Optionally, log the arrays to check their contents
	// console.log("Taluka Codes:", talukaCode);
	// console.log("Taluka Names:", talukaName);
	
			// Create options dynamically and append to the select element
			let talukaSelect = document.getElementById('taluka');

			talukaCode.forEach((code, index) => {
				// Create a new <option> element
				let option = document.createElement('option');
				
				// Set the value and text for the <option> element
				option.value = code;  // Set the value attribute to thncode11
				option.textContent = talukaName[index];  // Set the text to thname11
				
				// Optionally, set an id attribute to the option (if needed)
				option.id = `taluka-option-${code}`;
				
				// Append the option to the select element
				talukaSelect.appendChild(option);
			});

  });

// --------------------------------------------------------------------------------------------










document.getElementById('taluka').onchange = function () {
	
	map.removeLayer(taluka_geojson);
	//map.removeLayer(cropsap);
	//map.removeLayer(geojson_dist_cropsap);
	//map.removeLayer(geojson_tal_cropsap);
	map.removeLayer(geojson_District);
	//map.removeLayer(cropsap_dist);

	var tal_value = document.getElementById('taluka').value;
	let taluka_value = `thncode11= +'${tal_value}'`;

	// console.log("Taluka value : "+taluka_value)
	

	let tal_text = document.getElementById('taluka');
	var taluka_text = tal_text.options[tal_text.selectedIndex].text;

	//console.log( taluka_value);
	let taluka_json = "http://localhost:8282/geoserver/portal/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=portal%3ATaluka&maxFeatures=50&CQL_FILTER=" + taluka_value + "&outputFormat=application/json";

	// console.log(taluka_json);
	taluka_geojson = new ol.layer.Vector({
		title: 'Taluka',
		source: new ol.source.Vector({
			url: taluka_json,
			format: new ol.format.GeoJSON(),
		}),
		style: function (feature) {
			// Define the base style for your vector features
			let baseStyle = new ol.style.Style({
				fill: new ol.style.Fill({
					color: [255, 255, 0, 0], // Adjust the color and opacity as needed (10% opacity)
				}),
				stroke: new ol.style.Stroke({
					color: [255, 0, 0, 1], // Black stroke color with full opacity
					width: 3, // Stroke width in pixels
					lineDash: [6, 6],
				}),
				// Define your existing style properties here
			});

			// Apply the mask style over the base style
			return [baseStyle]; // Reversed order to put maskStyle on top
		},
	});

	taluka_geojson.getSource().on('addfeature', function () {
		let containerSize = [document.getElementById('map').clientWidth, document.getElementById('map').clientHeight];
		map.getView().fit(
			taluka_geojson.getSource().getExtent(), {
			duration: 90,
			size: containerSize,
			padding: [30, 30, 30, 30]
		}
		);
	});

	const style = new ol.style.Style({
		fill: new ol.style.Fill({
			color: 'black',
		}),
	});

	map.addLayer(taluka_geojson);


		// console.log('we are here');



// The thncode11 value you want to pass as a filter
let targetThncode11 = tal_value; // Example value

// URL to GeoServer WFS with CQL_FILTER to filter by thncode11
let url = `http://localhost:8282/geoserver/portal/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=portal%3AVillage_Master&maxFeatures=50&outputFormat=application%2Fjson&CQL_FILTER=thncode11='${targetThncode11}'`;

// Fetch data from GeoServer using the modified URL
fetch(url)
    .then(response => response.json())
    .then(data => {
        // Check if the data contains features
        if (data.features) {
            // Initialize arrays to store the vc_c11_code and vc_c11_name
            let vc_c11_codes = [];
            let vc_c11_names = [];

            // Loop through features and extract vc_c11_code and vc_c11_name
            data.features.forEach(item => {
                let vc_c11_code = item.properties.vc_c11; // Assuming vc_c11 is the correct property for the code
                let vc_c11_name = item.properties.name; // Assuming 'name' is the correct property for the name

                // Add the values to the arrays
                vc_c11_codes.push(vc_c11_code);
                vc_c11_names.push(vc_c11_name);

                // Log the values (optional)
                // console.log("vc_c11 Code:", vc_c11_code);
                // console.log("vc_c11 Name:", vc_c11_name);
            });

            // Create options dynamically and append them to the select element
            let villageSelect = document.getElementById('village');
            vc_c11_codes.forEach((code, index) => {
                // Create a new <option> element
                let option = document.createElement('option');

                // Set the value and text for the <option> element
                option.value = code;  // Set the value attribute to vc_c11_code
                option.textContent = vc_c11_names[index];  // Set the text to vc_c11_name

                // Optionally, set an id attribute to the option (if needed)
                option.id = `village-option-${code}`;

                // Append the option to the select element
                villageSelect.appendChild(option);
            });
        }
    })
    .catch(error => {
        console.error("Error fetching data:", error);
    });



		



	
} //Completed Select Taluka Function



// --------------------------------------------------------------------------------------------------------------


// document.getElementById('village').onchange = function () {
	
// 	map.removeLayer(taluka_geojson);
// 	map.removeLayer(geojson_District);
	

// 	var vil_value = document.getElementById('village').value;
// 	let village_value = `vc_c11='${vil_value}'`;

// 	// console.log("village value : "+ village_value)
	

// 	let tal_text = document.getElementById('taluka');
// 	var taluka_text = tal_text.options[tal_text.selectedIndex].text;

// 	//console.log( taluka_value);
// 	let village_json = "http://localhost:8282/geoserver/portal/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=portal%3AVillage&maxFeatures=50&CQL_FILTER=" + village_value + "&outputFormat=application/json";

// 	// console.log(village_json);
// 	village_geojson = new ol.layer.Vector({
// 		title: 'Taluka',
// 		source: new ol.source.Vector({
// 			url: village_json,
// 			format: new ol.format.GeoJSON(),
// 		}),
// 		style: function (feature) {
// 			// Define the base style for your vector features
// 			let baseStyle = new ol.style.Style({
// 				fill: new ol.style.Fill({
// 					color: [255, 255, 0, 0], // Adjust the color and opacity as needed (10% opacity)
// 				}),
// 				stroke: new ol.style.Stroke({
// 					color: [255, 0, 0, 1], // Black stroke color with full opacity
// 					width: 3, // Stroke width in pixels
// 					lineDash: [6, 6],
// 				}),
// 				// Define your existing style properties here
// 			});

// 			// Apply the mask style over the base style
// 			return [baseStyle]; // Reversed order to put maskStyle on top
// 		},
// 	});

// 	village_geojson.getSource().on('addfeature', function () {
// 		let containerSize = [document.getElementById('map').clientWidth, document.getElementById('map').clientHeight];
// 		map.getView().fit(
// 			village_geojson.getSource().getExtent(), {
// 			duration: 90,
// 			size: containerSize,
// 			padding: [30, 30, 30, 30]
// 		}
// 		);
// 	});

// 	const style = new ol.style.Style({
// 		fill: new ol.style.Fill({
// 			color: 'black',
// 		}),
// 	});

// 	map.addLayer(village_geojson);

// 	var allLayers = [Watershed_Prority_Boundary, districtLayer, Taluka_Boundary, Road_Layer, Rail_Track_Layer, Settlement_Point, ContourLayer];

// 	allLayers.forEach(function(layer) {
// 		layer.on('postrender', function(e) {
// 			const vectorContext = ol.render.getVectorContext(e);
// 			e.context.globalCompositeOperation = 'destination-in';  // This applies the clipping
			
// 			// Loop through each feature of the layer and apply the style
// 			layer.getSource().forEachFeature(function (feature) {
// 				vectorContext.drawFeature(feature, style);
// 			});

// 			e.context.globalCompositeOperation = 'source-over';  // Reset back to default
// 		});
// 	});



// 		// console.log('we are here');



		



	
// } //Completed Select Taluka Function



// // -------------------------------------------------------------------------------------------------------------------------------------






// map.addLayer(basemap);
// map.addLayer(Watershed_Prority_Boundary);
// map.addLayer(districtLayer);
// map.addLayer(Taluka_Boundary);
// map.addLayer(Village_Boundary);
// // map.addControl(village_name);
// map.addLayer(Road_Layer);
// map.addLayer(Rail_Track_Layer);
// map.addLayer(Settlement_Point);
// map.addLayer(ContourLayer);



document.getElementById('village').onchange = function () {
    // Remove existing layers
    map.removeLayer(taluka_geojson);
    map.removeLayer(geojson_District);

    var vil_value = document.getElementById('village').value;
    let village_value = `vc_c11='${vil_value}'`;  // Village CQL Filter

    let tal_text = document.getElementById('taluka');
    var taluka_text = tal_text.options[tal_text.selectedIndex].text;

    // Fetch new village GeoJSON data based on the selected village value
    let village_json = `http://localhost:8282/geoserver/portal/ows?service=WFS&version=1.0.0&request=GetFeature&typeName=portal%3AVillage&maxFeatures=50&CQL_FILTER=${village_value}&outputFormat=application/json`;

    village_geojson = new ol.layer.Vector({
        title: 'Village',
        source: new ol.source.Vector({
            url: village_json,
            format: new ol.format.GeoJSON(),
        }),
        style: function (feature) {
            // Define the base style for your vector features (e.g., yellow fill and red stroke)
            let baseStyle = new ol.style.Style({
                fill: new ol.style.Fill({
                    color: [255, 255, 0, 0.1],  // 10% opacity for fill
                }),
                stroke: new ol.style.Stroke({
                    color: [255, 0, 0, 1],  // Red stroke with full opacity
                    width: 3,  // Stroke width
                    lineDash: [6, 6],  // Dashed stroke pattern
                }),
            });
            return [baseStyle];  // Return base style
        },
    });

    // When features are added, fit the map view to the extent of the village
    village_geojson.getSource().on('addfeature', function () {
        let containerSize = [document.getElementById('map').clientWidth, document.getElementById('map').clientHeight];
        map.getView().fit(
            village_geojson.getSource().getExtent(), {
            duration: 90,
            size: containerSize,
            padding: [30, 30, 30, 30]
        });
    });

    // Add the village layer to the map
    map.addLayer(village_geojson);

    // Define the clipping style
    const clipStyle = new ol.style.Style({
        fill: new ol.style.Fill({
            color: 'black',  // Black fill for clipping effect
        }),
    });



	
}


// Ensure the clipping effect applies by adjusting the order of layers
    // For example, add layers to the map here after applying the clipping
    map.addLayer(basemap);
    map.addLayer(districtLayer);
    map.addLayer(Taluka_Boundary);
    map.addLayer(Road_Layer);
    map.addLayer(Rail_Track_Layer);
    map.addLayer(Settlement_Point);
    map.addLayer(ContourLayer);
	map.addLayer(Village_Boundary);






	document.getElementById("submit").onclick = function () {


		// map.addLayer(districtLayer);
		// map.addLayer(Taluka_Boundary);
		// map.addLayer(Road_Layer);
		// map.addLayer(Rail_Track_Layer);
		// map.addLayer(Settlement_Point);
		// map.addLayer(ContourLayer);



		
	};
	
	
	

	





// Function to create the Layer Switcher HTML interface
function createLayerSwitcher() {
    var container = document.createElement('div');
    container.className = 'ol-layerSwitcher';

    // Loop through all layers and create a checkbox for each layer
    map.getLayers().forEach(function(layer, index) {
        if (layer.get('title')) {
            var label = document.createElement('label');
            var checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.checked = true; // Ensure all layers are checked by default
            checkbox.onchange = function() {
                layer.setVisible(checkbox.checked);
            };

            label.appendChild(checkbox);
            label.appendChild(document.createTextNode(layer.get('title')));
            container.appendChild(label);
            container.appendChild(document.createElement('br'));
        }
    });

    return container;
}

// Add the Layer Switcher to the map
var layerSwitcher = createLayerSwitcher();
document.body.appendChild(layerSwitcher);




// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

document.getElementById('refresh').onclick = function () {
	window.location.reload();
};




//Mouse Position
let Mouse = new ol.control.MousePosition({ 
	className: 'custom-mouse-position',
	projection: 'EPSG:4326',
	coordinateFormat: function(coordinate) {
		return ol.coordinate.format(coordinate, 'Lat : {y} / Lon : {x}', 4);
	},
	target: document.getElementById('mouse-position') // Specify the target element
});
map.addControl(Mouse);

// Get the map element
var mapElement = document.getElementById('map');


// Define a function to update the scale text
function updateScaleText() {
	// Get the scale line element by class name
	var scaleLineElement = document.getElementsByClassName('ol-scale-line-inner')[0];

	// Check if the element exists before accessing its innerText
	if (scaleLineElement) {
		// Prepend '1 cm :' to the scale text
		document.getElementById('scale-line').innerHTML = '1 cm : ' + scaleLineElement.innerText;
	} else {
		console.error('Scale line element not found.');
	}
}

// Assuming the map is already created and stored in the variable 'map'
// Create the ScaleLine control
let Scale_Line = new ol.control.ScaleLine({
	units: 'metric',
	bar: false, // Hide the scale bar
	text: true,
	steps: 2,
	minWidth: 100
});

// Wait for the 'rendercomplete' event to ensure the map is fully rendered
map.once('rendercomplete', function () {
	// Add the Scale_Line control to the map
	map.addControl(Scale_Line);

	// Call the function to update the scale text
	updateScaleText();
});

// Listen for the 'moveend' event, which is triggered when the map view is moved
map.on('moveend', function () {
	updateScaleText();
});

// Listen for the 'zoomend' event, which is triggered when the map view is zoomed
map.on('zoomend', function () {
	updateScaleText();
});








// // Add the custom scale bar control to the map
// map.addControl(new ol.control.Control({element: new CustomScaleBar()}));


map.addControl(Scale_Line);

// map.addControl(Mouse);
map.addLayer(districtLayer);
map.removeLayer(base);

// -------------------------------------------------------------------------------------------------------------------------------------














// Function to display custom alert dialog
function alert(message) {
	var customAlert = document.getElementById('customAlert');
	var alertMessage = customAlert.querySelector('.alert-message');

	// Set the message content
	alertMessage.textContent = message;

	// Show the custom alert dialog
	customAlert.style.display = 'block';

	// Hide the custom alert dialog after a certain time
	setTimeout(function () {
		customAlert.style.display = 'none';
	}, 3000); // Adjust the time (in milliseconds) as needed
}






// Function to create the tooltip
const createTooltip = function (map) {
    const tooltipElement = document.createElement('div');
    tooltipElement.className = 'ol-tooltip hidden';
    document.body.appendChild(tooltipElement);

    const tooltip = new ol.Overlay({
        element: tooltipElement,
        offset: [15, 0],
        positioning: 'center-left',
    });

    map.addOverlay(tooltip);
    return tooltip;
};

// Function to start line and area measurement interactions
const startMeasureInteraction = function(type) {
    // Clear existing interactions
    map.getInteractions().forEach(function (interaction) {
        if (interaction instanceof ol.interaction.Draw) {
            map.removeInteraction(interaction);
        }
    });

    // Create a new measure interaction
    const source = new ol.source.Vector();
    const vectorLayer = new ol.layer.Vector({
        source: source,
    });
    map.addLayer(vectorLayer);

    const tooltip = createTooltip(map);
    const draw = new ol.interaction.Draw({
        source: source,
        type: type,
    });

    draw.on('drawstart', function (event) {
        // Clear the tooltip content and hide it when drawing starts
        tooltip.getElement().classList.add('hidden');
        tooltip.getElement().innerHTML = ''; // Clear any existing content
    });

    draw.on('drawend', function (event) {
        const geometry = event.feature.getGeometry();
        let output;

        // Calculate the measurement based on the type of drawing (Line or Area)
        if (type === 'LineString') {
            output = formatLength(geometry);
        } else if (type === 'Polygon') {
            output = formatArea(geometry);
        }

        // Position and display the tooltip with the result (only after drawing ends)
        tooltip.setPosition(geometry.getLastCoordinate());
        tooltip.getElement().classList.remove('hidden');
        tooltip.getElement().innerHTML = output;
    });

    map.addInteraction(draw);
};

// Create a Sphere instance for measurement calculations (Earth radius in meters)
const sphere = new ol.Sphere(6371000);

// Format length of line
function formatLength(line) {
    const length = sphere.getLength(line);
    return 'Length: ' + (Math.round(length * 100) / 100) + ' meters'; // Round to 2 decimal places
}

// Format area of polygon
function formatArea(polygon) {
    const area = sphere.getArea(polygon);
    return 'Area: ' + (Math.round(area * 100) / 100) + ' square meters'; // Round to 2 decimal places
}

// Add event listeners to buttons
document.getElementById('measure-line').onclick = function() {
    startMeasureInteraction('LineString');
};

document.getElementById('measure-area').onclick = function() {
    startMeasureInteraction('Polygon');
};

