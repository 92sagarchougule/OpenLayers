//window.onload = init

//function init(){

    //const scaleLine = new ol.control.ScaleLine();
    //const mpost = new ol.control.MousePosition({
        //coordinates: coordinate.format(5)
    //});
    var attri = new ol.control.Attribution();

    // Controls

    const map = new ol.Map({
        view: new ol.View({
            center:[8416632.556336425,1731769.3201302553],
            zoom:15
        }),
        layers:[
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        target:'map',
        //controls : ol.control.defaults({ zoom: false, attribution: false }).extend([scaleLine,mpost, attri])
    });

    /*
    const popupNewContainer = document.getElementById('popup-container');

    const  popupContainer = document.getElementById('popup-coordinate');
    var closer = document.getElementById('popup-closer');

    const popup = new ol.Overlay({
        element:popupNewContainer
    })

    closer.onclick = function() {
        popup.setPosition(undefined);
        closer.blur();
        return false;
    };

    map.addOverlay(popup);

    map.on('click', function(e){
        var clicked = e.coordinate;
        popup.setPosition(undefined);
        popup.setPosition(clicked);
        popupContainer.innerHTML = clicked;
    })
    */
/*
    const dragBox = new ol.interaction.DragBox({
        className:'dragBox'
    })

    dragBox.on('boxstart', function(evt){
        //console.log('drag start');
    })

    dragBox.on('boxend', function(evt){
        //console.log('drag end')

        map.getView().fit(dragBox.getGeometry().getExtent(), map.getSize())
    })

    map.addInteraction(dragBox);
    */
/*
    var dragSource = new ol.source.Vector()  // add source

    var dragLayer = new ol.layer.Vector({  // add layer to map canvas
        source:dragSource
    })
    map.addLayer(dragLayer);

    var dragDrop = new ol.interaction.DragAndDrop({   // add layer to dragand Drop
        formatConstructors:[ol.format.KML],
        source:dragSource
    })

    map.addInteraction(dragDrop);

    dragDrop.on('addfeatures',function(evt){
        console.log('added features');
    })

    var drawSource = new ol.source.Vector()

    var drawLayer = new ol.layer.Vector({
        source:drawSource
    })

    map.addLayer(drawLayer);

    var dragDraw = new ol.interaction.Draw({
        type:'LineString',
        source:drawSource,
        freehand:true
    });

    map.addInteraction(dragDraw);

    dragDraw.on('drawend',function(evt){

        console.log(evt.feature.getGeometry().getCoordinates());
        })
*/

    var drawSource = new ol.source.Vector();

    var drawLayer = new ol.layer.Vector({
        source: drawSource
    })
    map.addLayer(drawLayer);

    var draw = new ol.interaction.Draw({
        type:'Point',
        source:drawSource
    })

    function addFeatures(){
        map.addInteraction(draw);
    }


    draw.on('drawend', function(evt){
        var cordinate = evt.feature.A.geometry.flatCoordinates;
        var y = cordinate[0]
        var x = cordinate[1]
        alert('X: ' + x + ' | Y: '+ y)
        map.removeInteraction(draw);
        
    })
    
//}
