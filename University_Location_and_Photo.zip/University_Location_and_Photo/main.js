window.onload = init

function init(){
    // main classes
    const map = new ol.Map({ // map class
        view: new ol.View({  // view class
            //projection:'EPSG:4326',
            center:[8416598.169912841, 1731976.3818193525],
            zoom:15
        }),
        target:'map'
    });

    var base_maps = new ol.layer.Group({
        'title': 'Base maps',
        layers: [

    
            new ol.layer.Tile({
                title: 'Satellite',
                //type: 'base',
                visible: true,
                source: new ol.source.XYZ({
                    attributions: ['Powered by Esri',
                        'Source: Esri, DigitalGlobe, GeoEye, Earthstar Geographics, CNES/Airbus DS, USDA, USGS, AeroGRID, IGN, and the GIS User Community'
                    ],
                    attributionsCollapsible: false,
                    url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
                    maxZoom: 23
                })
            }),

            new ol.layer.Tile({
                title: 'OSM',
                //type: 'base',
                visible: false,
                source: new ol.source.OSM()
            })
        ]
    });

    map.addLayer(base_maps);
    //Added Layer from Geoserver
    
    
    //Contour Layer from Geoserver
    /*

    const contour = new ol.layer.Tile({
        source:new ol.source.TileWMS({
            url:'http://localhost:8080/geoserver/wms',
            params:{'LAYERS':'ksrdpru:contour.'},
            serverType:'geoserver'
        }),
        title:'Contour'
    });
    map.addLayer(contour);
    
    
    const Boundry = new ol.layer.Tile({
        source: new ol.source.TileWMS({
            url: 'http://localhost:8080/geoserver/wms',
            params: {'LAYERS': 'ksrdpru:lineboundry'},
            serverType: 'geoserver'
          }),
          title:'Boundry'
    });
    map.addLayer(Boundry);
    
    


    //Building Layer from Geoserver
    const Building = new ol.layer.Tile({
        source: new ol.source.TileWMS({
            url: 'http://localhost:8080/geoserver/wms',
            params: {'LAYERS': 'ksrdpru:buildings', 'src':'EPSG:4326', 'transparent':true},
            serverType: 'geoserver'
          }),
          title:'Building'
    });
    map.addLayer(Building);
    */

    var Style  = new ol.style.Style({

        image: new ol.style.Circle({
            radius:8,
            fill: new ol.style.Fill({
                color:'#ed0c39'
            })
        })
    });

    var builPhoto = new ol.layer.Vector({
        title:'Landmark',
        source: new ol.source.Vector({
            url:'./lib/spatial_data/buildings.geojson',
            format: new ol.format.GeoJSON()
        }),
        style:Style
    });

    map.addLayer(builPhoto);

    var boundry = new ol.layer.Vector({
        title:'Boundry',
        source: new ol.source.Vector({
            url:'./lib/spatial_data/Lineboundry.geojson',
            format: new ol.format.GeoJSON()
        })
    });

    map.addLayer(boundry);
    

    
    

    // ScaleBar
    var scale_line = new ol.control.ScaleLine({
        units: 'metric',
        bar: true,
        steps: 6,
        text: true,
        minWidth: 140,
        target: 'scale_bar'
    });
    map.addControl(scale_line);
    

    

    // LayerSwitcher
    var layerSwitcher = new ol.control.LayerSwitcher({
        activationMode: 'click',
        startActive:true,
        groupSelectStyle:'children',
        collapseTipLabel: 'Collapse layers'
    })
    map.addControl(layerSwitcher);


    const overlayContainerElement = document.querySelector('.overlay-container');

    const overlayName = document.getElementById('feature-name');
    const overlayArea = document.getElementById('feature-area');
    var closer = document.getElementById('popup-closer');

    const overlayLayer = new ol.Overlay({
        element: overlayContainerElement
    });

    map.addOverlay(overlayLayer);
    

    closer.onclick = function() {
        overlayLayer.setPosition(undefined);
        closer.blur();
        return false;
    };

    
    featureOverlay = new ol.layer.Vector({
        tile:'highlight',
        source: new ol.source.Vector(),
        map: map
    });

    map.on('click', highlight);

    function highlight(evt) {
        if (featureOverlay) {
            featureOverlay.getSource().clear();
            map.removeLayer(featureOverlay);
            
        }
        
        feature = map.forEachFeatureAtPixel(evt.pixel,
            function(feature, layer) {
                return feature;
            });
            
    
        if (feature) {
            const coordinate =  evt.coordinate;
            let featureName = feature.get('Name'); //.getKeys()
            let featureArea = feature.get('Photo');
            overlayLayer.setPosition(coordinate);
            overlayName.innerHTML = featureName;
            overlayArea.innerHTML = featureArea;
        }
        }
}

