//window.onload = init

//function init(){

    //const scaleLine = new ol.control.ScaleLine();
    //const mpost = new ol.control.MousePosition({
        //coordinates: coordinate.format(5)
    //});
    var attri = new ol.control.Attribution();

    // Controls

    const map = new ol.Map({
        view: new ol.View({
            center:[8416632.556336425,1731769.3201302553],
            zoom:15
        }),
        layers:[
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        target:'map',
        //controls : ol.control.defaults({ zoom: false, attribution: false }).extend([scaleLine,mpost, attri])
    });

/*
    var dragSource = new ol.source.Vector()  // add source

    var dragLayer = new ol.layer.Vector({  // add layer to map canvas
        source:dragSource
    })
    map.addLayer(dragLayer);

    var dragDrop = new ol.interaction.DragAndDrop({   // add layer to dragand Drop
        formatConstructors:[ol.format.KML],
        source:dragSource
    })

    
    /*
    var drawSource = new ol.source.Vector();

    var drawLayer = new ol.layer.Vector({
        source: drawSource
    })
    map.addLayer(drawLayer);

    var draw = new ol.interaction.Draw({
        type:'Point',
        source:drawSource
    })

    function addFeatures(){
        map.addInteraction(draw);
    }


    draw.on('drawend', function(evt){
        var cordinate = evt.feature.A.geometry.flatCoordinates;
        //var y = cordinate[0]
        //var x = cordinate[1]
        $(elements).modal('show')
        //alert('X: ' + x + ' | Y: '+ y)
        map.removeInteraction(draw);
        
    })
    */

    const dragBox = new ol.interaction.DragBox({
        className:'dragBox'

    })

    

    function zoomIn(){
        map.addInteraction(dragBox);
    }

    dragBox.on('boxstart', function(e){
        console.log('start box');
    })
    
    dragBox.on('boxend',function(e){
        //alert(e.feature.getGeometry().getExtent());
        console.log('box end');
        var extent = dragBox.getGeometry().getExtent();
        map.getView().fit(extent, map.getSize());
    });
    
//}
