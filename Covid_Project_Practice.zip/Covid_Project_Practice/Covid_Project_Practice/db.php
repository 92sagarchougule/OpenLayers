<?php

$server:'localhost';
$username:'postgres';
$password:'123';
$db_name:'covid_range';

$dbcon = pg_coonect("host = $server port=5432 dbname=$db_name user=$username password=$password")

?>