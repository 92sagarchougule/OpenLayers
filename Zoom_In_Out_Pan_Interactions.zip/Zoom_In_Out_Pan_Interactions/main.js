
    var attri = new ol.control.Attribution();

    // Controls

    const map = new ol.Map({
        view: new ol.View({
            center:[8416632.556336425,1731769.3201302553],
            zoom:15
        }),
        layers:[
            new ol.layer.Tile({
                source: new ol.source.OSM()
            })
        ],
        target:'map'
    });

    // Zoom In Interaction
    const dragBox = new ol.interaction.DragBox({
        className:'zoomIn'
    })

    function zoomIn(){
        map.addInteraction(dragBox);
        map.removeInteraction(dragPan);
        map.removeInteraction(dragBoxOut);
    }
    
    dragBox.on('boxend',function(e){
        //alert(e.feature.getGeometry().getExtent());
        //console.log('box end');
        var extent = dragBox.getGeometry().getExtent();
        map.getView().fit(extent, map.getSize());
    });

    //let btnZoomin = document.querySelector('#zoomIns');
    //btnZoomin.addEventListener('click',() => btnZoomin.style.backgroundColor='red');

    // Pan Interaction
    var dragPan = new ol.interaction.DragPan({})
    
    function panImg(){
        map.addInteraction(dragPan);
        map.removeInteraction(dragBox)
        map.removeInteraction(dragBoxOut)
    }



    //Zoom Out Interaction
    var dragBoxOut = new ol.interaction.DragBox({
        className:'zoomOut'
    })
    
    function zoomOut(){
        map.addInteraction(dragBoxOut);
    }

    dragBoxOut.on('boxend', function(e){
        map.removeInteraction(dragPan);
        map.removeInteraction(dragBox)
        map.getView().animate({
            zoom: map.getView().getZoom() - 1,
            duration: 250
        })
    })
    
